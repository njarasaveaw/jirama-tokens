# JIRAMA Tokens - Application Android Native (Flutter)

## Fonctionnalités
- ✅ Génération du code USSD JIRAMA
- ✅ Appel USSD direct depuis l'app
- ✅ **Lecture automatique des 2 SMS de réponse après 30 secondes**
- ✅ Compte à rebours visuel pendant l'attente
- ✅ Sauvegarde locale des contacts
- ✅ Navigation par onglets (Achat / Contacts / Guide)

---

## Structure du projet

```
jirama_flutter/
├── lib/
│   ├── main.dart           ← Interface principale Flutter
│   ├── models.dart         ← Modèles de données
│   ├── sms_service.dart    ← Service lecture SMS + appel USSD
│   └── storage_service.dart← Sauvegarde contacts (SharedPreferences)
├── android/
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── AndroidManifest.xml          ← Permissions READ_SMS, CALL_PHONE
│   │   │   └── kotlin/com/bargass/jirama/
│   │   │       └── MainActivity.kt          ← Bridge natif Android (SMS + USSD)
│   │   └── build.gradle
│   └── build.gradle
└── pubspec.yaml            ← Dépendances Flutter
```

---

## Installation & Compilation

### Prérequis
- [Flutter SDK](https://docs.flutter.dev/get-started/install) ≥ 3.0
- Android Studio avec Android SDK
- Un téléphone Android (physique recommandé pour les SMS)

### Étapes

```bash
# 1. Installer Flutter (si pas encore fait)
# https://docs.flutter.dev/get-started/install/windows

# 2. Cloner / copier ce projet
cd jirama_flutter

# 3. Installer les dépendances
flutter pub get

# 4. Connecter votre téléphone Android en USB (activer débogage USB)

# 5. Lancer l'app en mode debug
flutter run

# 6. Compiler l'APK de release
flutter build apk --release
# → APK généré dans: build/app/outputs/flutter-apk/app-release.apk
```

### Installer l'APK sur Android
```bash
# Via ADB (câble USB)
adb install build/app/outputs/flutter-apk/app-release.apk

# Ou transférer le fichier APK sur le téléphone et ouvrir depuis le gestionnaire de fichiers
# (Autoriser l'installation depuis sources inconnues dans les paramètres)
```

---

## Comment fonctionne la lecture des SMS

1. **Appel USSD** → L'app appelle via `tel:` le code USSD sur votre ligne TELMA/YAS
2. **Déclenchement du timer** → Compte à rebours de 30 secondes affiché
3. **Polling toutes les 5 secondes** → L'app lit la boîte de réception SMS Android
4. **Filtrage** → Filtre les SMS de : JIRAMA, TELMA, YAS, MVola
5. **Affichage** → Les 2 premiers SMS reçus après l'appel sont affichés avec heure et expéditeur

### Permissions Android requises
- `READ_SMS` → Lire les messages reçus
- `RECEIVE_SMS` → Écouter les SMS en temps réel
- `CALL_PHONE` → Composer l'appel USSD

---

## Notes importantes
- ⚠️ Utiliser uniquement sur ligne **TELMA** ou **YAS**
- ⚠️ Certains opérateurs bloquent les appels USSD depuis les apps → utiliser un dialer alternatif si nécessaire
- Le canal natif `MainActivity.kt` communique avec Flutter via `MethodChannel` et `EventChannel`

---
**Bargass APK · JIRAMA Tokens v1.0**
