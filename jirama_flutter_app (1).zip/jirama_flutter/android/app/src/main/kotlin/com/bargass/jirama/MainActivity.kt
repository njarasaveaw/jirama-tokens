package com.bargass.jirama

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val METHOD_CHANNEL = "com.bargass.jirama/ussd"
    private val EVENT_CHANNEL  = "com.bargass.jirama/sms_stream"

    private var smsEventSink: EventChannel.EventSink? = null
    private var smsReceiver: BroadcastReceiver? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // ── Method Channel: lire SMS depuis la boîte de réception ──
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, METHOD_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getRecentSms" -> {
                        val afterTimestamp = call.argument<Long>("afterTimestamp") ?: 0L
                        val senders       = call.argument<List<String>>("senders") ?: emptyList()
                        val limit         = call.argument<Int>("limit") ?: 5
                        result.success(readRecentSms(afterTimestamp, senders, limit))
                    }
                    "dialUssd" -> {
                        val code = call.argument<String>("code") ?: ""
                        val ussd = Uri.encode(code)
                        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$ussd"))
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }

        // ── Event Channel: stream SMS entrants en temps réel ──
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EVENT_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    smsEventSink = events
                    registerSmsReceiver()
                }
                override fun onCancel(arguments: Any?) {
                    smsReceiver?.let { unregisterReceiver(it) }
                    smsReceiver = null
                    smsEventSink = null
                }
            })
    }

    private fun registerSmsReceiver() {
        smsReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
                val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
                for (msg in messages) {
                    val data = mapOf(
                        "address" to (msg.originatingAddress ?: ""),
                        "body"    to msg.messageBody,
                        "date"    to System.currentTimeMillis()
                    )
                    runOnUiThread { smsEventSink?.success(data) }
                }
            }
        }
        val filter = IntentFilter(Telephony.Sms.Intents.SMS_RECEIVED_ACTION).apply {
            priority = 999
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(smsReceiver, filter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(smsReceiver, filter)
        }
    }

    /** Lit les SMS récents depuis la boîte de réception Android */
    private fun readRecentSms(
        afterTimestamp: Long,
        senders: List<String>,
        limit: Int
    ): List<Map<String, Any>> {
        val results = mutableListOf<Map<String, Any>>()
        val uri     = Uri.parse("content://sms/inbox")
        val projection = arrayOf("address", "body", "date")

        var selection = "date > ?"
        val selArgs   = mutableListOf(afterTimestamp.toString())

        if (senders.isNotEmpty()) {
            val placeholders = senders.joinToString(",") { "?" }
            selection += " AND (${senders.joinToString(" OR ") { "address LIKE ?" }})"
            senders.forEach { selArgs.add("%$it%") }
        }

        val cursor: Cursor? = contentResolver.query(
            uri, projection, selection, selArgs.toTypedArray(), "date DESC"
        )
        cursor?.use {
            var count = 0
            while (it.moveToNext() && count < limit) {
                results.add(mapOf(
                    "address" to (it.getString(0) ?: ""),
                    "body"    to (it.getString(1) ?: ""),
                    "date"    to (it.getLong(2))
                ))
                count++
            }
        }
        return results
    }
}

/** Receiver déclaré dans le Manifest pour réception en arrière-plan */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Géré par MainActivity via EventChannel quand l'app est ouverte
    }
}
