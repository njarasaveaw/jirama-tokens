// lib/storage_service.dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class StorageService {
  static const _key = 'jirama_contacts';

  Future<List<Contact>> loadContacts() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw.map((s) => Contact.fromJson(jsonDecode(s))).toList();
  }

  Future<void> saveContacts(List<Contact> contacts) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _key,
      contacts.map((c) => jsonEncode(c.toJson())).toList(),
    );
  }

  Future<void> addContact(Contact contact) async {
    final list = await loadContacts();
    if (!list.any((c) => c.name == contact.name)) {
      list.add(contact);
      await saveContacts(list);
    }
  }

  Future<void> deleteContact(int index) async {
    final list = await loadContacts();
    if (index >= 0 && index < list.length) {
      list.removeAt(index);
      await saveContacts(list);
    }
  }
}
