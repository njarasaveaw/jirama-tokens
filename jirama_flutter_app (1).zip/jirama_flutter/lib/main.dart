// lib/main.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:intl/intl.dart';
import 'models.dart';
import 'sms_service.dart';
import 'storage_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const JiramaApp());
}

// ─────────────────────────────────────────────
class JiramaApp extends StatelessWidget {
  const JiramaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'JIRAMA Tokens',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF1565C0),
            brightness: Brightness.light,
          ),
          useMaterial3: true,
          fontFamily: 'Roboto',
        ),
        home: const HomeScreen(),
      );
}

// ─────────────────────────────────────────────
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  final _sms     = SmsService();
  final _storage = StorageService();

  // Formulaire
  final _nameCtrl = TextEditingController();
  final _instCtrl = TextEditingController();
  final _compCtrl = TextEditingController();
  final _kwhCtrl  = TextEditingController();

  String? _generatedCode;
  bool    _callDone       = false;
  bool    _waitingSms     = false;
  List<SmsMessage> _smsResults = [];
  Timer?  _smsTimer;
  int     _countdown = 0;

  List<Contact> _contacts = [];

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _loadContacts();
  }

  @override
  void dispose() {
    _smsTimer?.cancel();
    _nameCtrl.dispose(); _instCtrl.dispose();
    _compCtrl.dispose(); _kwhCtrl.dispose();
    super.dispose();
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.sms,
      Permission.phone,
    ].request();
  }

  Future<void> _loadContacts() async {
    final list = await _storage.loadContacts();
    setState(() => _contacts = list);
  }

  String _onlyDigits(String v) => v.replaceAll(RegExp(r'\D'), '');

  String _buildUssd(String a, String b, String c) =>
      '#111*1*5*3*2*1*1*$a*$b*2*$c#';

  // ── Générer le code ──
  void _generate() {
    final name = _nameCtrl.text.trim();
    final a    = _onlyDigits(_instCtrl.text);
    final b    = _onlyDigits(_compCtrl.text);
    final c    = _onlyDigits(_kwhCtrl.text);

    if (name.isEmpty || a.isEmpty || b.isEmpty || c.isEmpty) {
      _showSnack('⚠️ Fenoy avokoa ny saha rehetra');
      return;
    }

    setState(() {
      _generatedCode = _buildUssd(a, b, c);
      _callDone      = false;
      _smsResults    = [];
      _waitingSms    = false;
    });

    // Enregistrer contact si nouveau
    _storage.addContact(Contact(name: name, inst: a, comp: b))
        .then((_) => _loadContacts());
  }

  // ── Appel USSD + attente SMS ──
  Future<void> _call() async {
    if (_generatedCode == null) return;

    final callTime = DateTime.now();
    await _sms.dialUssd(_generatedCode!);

    setState(() {
      _callDone   = true;
      _waitingSms = true;
      _smsResults = [];
      _countdown  = 30;
    });

    // Compte à rebours affiché
    _smsTimer?.cancel();
    _smsTimer = Timer.periodic(const Duration(seconds: 1), (t) async {
      if (!mounted) { t.cancel(); return; }

      setState(() => _countdown--);

      // Vérification SMS toutes les 5 secondes
      if (_countdown % 5 == 0 || _countdown <= 0) {
        final msgs = await _sms.getRecentSms(afterTime: callTime);
        if (msgs.isNotEmpty) {
          t.cancel();
          setState(() {
            _smsResults = msgs.take(2).toList();
            _waitingSms = false;
            _countdown  = 0;
          });
          return;
        }
      }

      if (_countdown <= 0) {
        t.cancel();
        if (mounted) setState(() => _waitingSms = false);
      }
    });
  }

  void _loadContact(Contact c) {
    _nameCtrl.text = c.name;
    _instCtrl.text = c.inst;
    _compCtrl.text = c.comp;
    setState(() { _tab = 0; _generatedCode = null; _smsResults = []; });
  }

  Future<void> _deleteContact(int index) async {
    await _storage.deleteContact(index);
    _loadContacts();
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  // ────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: cs.primary,
        foregroundColor: Colors.white,
        title: const Text('JIRAMA Tokens', style: TextStyle(fontWeight: FontWeight.w500)),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF00BCD4),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text('BARGASS APK',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                    color: Color(0xFF0D47A1), letterSpacing: 0.5)),
          ),
        ],
      ),
      body: IndexedStack(
        index: _tab,
        children: [_buildAchatTab(), _buildContactsTab(), _buildGuideTab()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.bolt), label: 'Achat'),
          NavigationDestination(icon: Icon(Icons.contacts), label: 'Contacts'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'Guide'),
        ],
      ),
    );
  }

  // ── Tab Achat ──
  Widget _buildAchatTab() {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        // Formulaire
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionHeader(Icons.person_outline, 'Informations client'),
                const SizedBox(height: 12),
                _textField(_nameCtrl, 'Pseudo', 'Ex: Rabe'),
                _textField(_instCtrl, 'N° Installation', 'Ex: 25111753721 (sans E)',
                    keyboard: TextInputType.number),
                _textField(_compCtrl, 'N° Compteur', 'Ex: 25119006627',
                    keyboard: TextInputType.number),
                _textField(_kwhCtrl, 'Kilowattheures (kWh)', 'Ex: 50',
                    keyboard: TextInputType.number, last: true),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),

        // Boutons
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              onPressed: _generate,
              icon: const Icon(Icons.flash_on),
              label: const Text('Générer'),
              style: FilledButton.styleFrom(
                  backgroundColor: Colors.green.shade600,
                  padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: FilledButton.icon(
              onPressed: _generatedCode != null ? _call : null,
              icon: const Icon(Icons.phone),
              label: const Text('Appeler'),
              style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
          ),
        ]),
        const SizedBox(height: 10),

        // Code généré
        if (_generatedCode != null) _buildCodeCard(),

        // Zone SMS
        if (_callDone) ...[
          const SizedBox(height: 10),
          _buildSmsSection(),
        ],
      ],
    );
  }

  Widget _buildCodeCard() {
    return Card(
      color: const Color(0xFF0D47A1),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('CODE USSD GÉNÉRÉ',
                style: TextStyle(fontSize: 11, color: Colors.white60, letterSpacing: 1)),
            const SizedBox(height: 8),
            SelectableText(
              _generatedCode!,
              style: const TextStyle(
                  fontFamily: 'monospace', fontSize: 15,
                  color: Color(0xFF80DEEA), height: 1.5),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.orange.shade800.withOpacity(0.3),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(children: [
                Icon(Icons.warning_amber, color: Colors.orange.shade300, size: 18),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text('Utiliser sur TELMA ou YAS uniquement',
                      style: TextStyle(color: Colors.white70, fontSize: 13)),
                ),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  // ── Section SMS après appel ──
  Widget _buildSmsSection() {
    if (_waitingSms) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            _sectionHeader(Icons.sms, 'Attente de la réponse SMS'),
            const SizedBox(height: 16),
            Stack(alignment: Alignment.center, children: [
              SizedBox(
                width: 80, height: 80,
                child: CircularProgressIndicator(
                  value: _countdown / 30,
                  strokeWidth: 6,
                  backgroundColor: Colors.grey.shade200,
                ),
              ),
              Column(mainAxisSize: MainAxisSize.min, children: [
                Text('$_countdown',
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                const Text('sec', style: TextStyle(fontSize: 12, color: Colors.grey)),
              ]),
            ]),
            const SizedBox(height: 12),
            const Text('Vérification des SMS entrants...',
                style: TextStyle(color: Colors.grey, fontSize: 14)),
          ]),
        ),
      );
    }

    if (_smsResults.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            _sectionHeader(Icons.sms_failed_outlined, 'Réponse SMS'),
            const SizedBox(height: 12),
            const Icon(Icons.inbox_outlined, size: 40, color: Colors.grey),
            const SizedBox(height: 8),
            const Text('Aucun SMS reçu après l\'appel.',
                style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 4),
            const Text('Vérifiez votre ligne TELMA/YAS.',
                style: TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionHeader(Icons.mark_email_read_outlined, 'SMS reçus (${_smsResults.length})'),
            const SizedBox(height: 12),
            ..._smsResults.asMap().entries.map((e) => _buildSmsCard(e.key + 1, e.value)),
          ],
        ),
      ),
    );
  }

  Widget _buildSmsCard(int n, SmsMessage msg) {
    final time = DateFormat('HH:mm:ss').format(msg.date);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.green.shade200),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(
            radius: 12,
            backgroundColor: Colors.green.shade600,
            child: Text('$n',
                style: const TextStyle(color: Colors.white, fontSize: 12,
                    fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(msg.address,
                style: TextStyle(fontWeight: FontWeight.w600,
                    color: Colors.green.shade800, fontSize: 13)),
          ),
          Text(time, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
        ]),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
          child: SelectableText(
            msg.body,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 13, height: 1.5),
          ),
        ),
      ]),
    );
  }

  // ── Tab Contacts ──
  Widget _buildContactsTab() {
    if (_contacts.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.person_add_alt, size: 64, color: Colors.grey.shade300),
          const SizedBox(height: 12),
          Text('Aucun contact enregistré',
              style: TextStyle(color: Colors.grey.shade500)),
        ]),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _contacts.length,
      itemBuilder: (ctx, i) {
        final c = _contacts[i];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.primary,
              child: Text(c.name[0].toUpperCase(),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            title: Text(c.name),
            subtitle: Text('Inst: ${c.inst}  ·  Cpt: ${c.comp}',
                style: const TextStyle(fontSize: 12)),
            onTap: () => _loadContact(c),
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
              onPressed: () => _confirmDelete(i, c.name),
            ),
          ),
        );
      },
    );
  }

  void _confirmDelete(int i, String name) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer ce contact ?'),
        content: Text('"$name" sera définitivement supprimé.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          TextButton(
            onPressed: () { Navigator.pop(ctx); _deleteContact(i); },
            child: const Text('Supprimer', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  // ── Tab Guide ──
  Widget _buildGuideTab() {
    final steps = [
      (Icons.edit_note, 'Remplir le formulaire',
          'Pseudo, n° d\'installation, n° de compteur et kWh souhaités.'),
      (Icons.flash_on, 'Générer le code USSD',
          'Appuyez sur "Générer". Le contact est enregistré automatiquement.'),
      (Icons.phone, 'Passer l\'appel',
          'Appuyez sur "Appeler". Utilisez TELMA ou YAS uniquement.'),
      (Icons.sms, 'Réception automatique des SMS',
          'L\'app attend 30 secondes et affiche les 2 SMS de réponse de JIRAMA automatiquement.'),
      (Icons.contacts, 'Gérer les contacts',
          'Onglet Contacts : appuyez pour recharger, icône poubelle pour supprimer.'),
    ];
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: steps.asMap().entries.map((e) {
                final (icon, title, desc) = e.value;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    CircleAvatar(
                      radius: 20,
                      backgroundColor:
                          Theme.of(context).colorScheme.primaryContainer,
                      child: Icon(icon,
                          color: Theme.of(context).colorScheme.primary, size: 20),
                    ),
                    const SizedBox(width: 14),
                    Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                        const SizedBox(height: 4),
                        Text(desc,
                            style: TextStyle(color: Colors.grey.shade600, height: 1.4)),
                      ],
                    )),
                  ]),
                );
              }).toList(),
            ),
          ),
        ),
        Card(
          color: Colors.blue.shade50,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Icon(Icons.security, color: Colors.blue.shade700),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Permissions requises',
                      style: TextStyle(fontWeight: FontWeight.w600,
                          color: Colors.blue.shade800)),
                  const SizedBox(height: 4),
                  Text('Téléphone (passer l\'appel USSD) et SMS (lire les réponses).',
                      style: TextStyle(fontSize: 13, color: Colors.blue.shade700)),
                ]),
              ),
            ]),
          ),
        ),
      ],
    );
  }

  // ── Helpers UI ──
  Widget _sectionHeader(IconData icon, String label) => Row(children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary, size: 20),
        const SizedBox(width: 8),
        Text(label.toUpperCase(),
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500,
                color: Colors.grey.shade600, letterSpacing: 0.5)),
      ]);

  Widget _textField(
    TextEditingController ctrl,
    String label,
    String hint, {
    TextInputType keyboard = TextInputType.text,
    bool last = false,
  }) =>
      Padding(
        padding: EdgeInsets.only(bottom: last ? 0 : 14),
        child: TextField(
          controller: ctrl,
          keyboardType: keyboard,
          decoration: InputDecoration(
            labelText: label,
            hintText: hint,
            hintStyle: TextStyle(fontSize: 13, color: Colors.grey.shade400),
            border: const UnderlineInputBorder(),
          ),
        ),
      );
}
