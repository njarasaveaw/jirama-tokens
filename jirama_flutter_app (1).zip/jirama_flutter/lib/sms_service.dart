// lib/sms_service.dart
import 'dart:async';
import 'package:flutter/services.dart';
import 'models.dart';

class SmsService {
  static const _method = MethodChannel('com.bargass.jirama/ussd');
  static const _events = EventChannel('com.bargass.jirama/sms_stream');

  Stream<SmsMessage>? _smsStream;

  /// Stream en temps réel des SMS entrants
  Stream<SmsMessage> get incomingSms {
    _smsStream ??= _events
        .receiveBroadcastStream()
        .map((e) => SmsMessage.fromMap(Map<String, dynamic>.from(e)));
    return _smsStream!;
  }

  /// Lance l'appel USSD via le canal natif
  Future<void> dialUssd(String code) async {
    await _method.invokeMethod('dialUssd', {'code': code});
  }

  /// Lit les SMS reçus après [afterTime], max [limit] messages
  /// Filtre optionnel sur les expéditeurs (ex: JIRAMA, TELMA)
  Future<List<SmsMessage>> getRecentSms({
    required DateTime afterTime,
    List<String> senders = const ['JIRAMA', 'TELMA', 'YAS', 'MVola'],
    int limit = 5,
  }) async {
    final raw = await _method.invokeListMethod<Map>('getRecentSms', {
      'afterTimestamp': afterTime.millisecondsSinceEpoch,
      'senders': senders,
      'limit': limit,
    });
    return (raw ?? []).map(SmsMessage.fromMap).toList();
  }

  /// Attend jusqu'à [maxWait] les SMS arrivant après [afterTime].
  /// Résout dès qu'on reçoit [expectedCount] messages ou à timeout.
  Future<List<SmsMessage>> waitForSmsAfterCall({
    required DateTime afterTime,
    int expectedCount = 2,
    Duration maxWait = const Duration(seconds: 60),
    Duration pollInterval = const Duration(seconds: 5),
  }) async {
    final deadline = DateTime.now().add(maxWait);
    while (DateTime.now().isBefore(deadline)) {
      await Future.delayed(pollInterval);
      final msgs = await getRecentSms(afterTime: afterTime);
      if (msgs.length >= expectedCount) return msgs.take(expectedCount).toList();
    }
    // Timeout : retourne ce qu'on a trouvé même si incomplet
    return getRecentSms(afterTime: afterTime);
  }
}
