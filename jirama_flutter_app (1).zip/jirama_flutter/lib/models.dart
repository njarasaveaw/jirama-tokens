// lib/models.dart

class Contact {
  final String name;
  final String inst;
  final String comp;

  Contact({required this.name, required this.inst, required this.comp});

  factory Contact.fromJson(Map<String, dynamic> j) =>
      Contact(name: j['name'], inst: j['inst'], comp: j['comp']);

  Map<String, dynamic> toJson() => {'name': name, 'inst': inst, 'comp': comp};
}

class SmsMessage {
  final String address;
  final String body;
  final DateTime date;

  SmsMessage({required this.address, required this.body, required this.date});

  factory SmsMessage.fromMap(Map m) => SmsMessage(
        address: m['address'] ?? '',
        body:    m['body']    ?? '',
        date:    DateTime.fromMillisecondsSinceEpoch((m['date'] as int?) ?? 0),
      );
}

class PurchaseRecord {
  final String contactName;
  final String ussdCode;
  final DateTime calledAt;
  final List<SmsMessage> responses;

  PurchaseRecord({
    required this.contactName,
    required this.ussdCode,
    required this.calledAt,
    this.responses = const [],
  });
}
