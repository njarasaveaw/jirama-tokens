# 📱 JIRAMA Tokens — Obtenir l'APK SANS PC

## Méthode : GitHub Actions (gratuit, 100% en ligne)

---

## ÉTAPES (15 minutes, depuis votre téléphone ou n'importe quel navigateur)

---

### ÉTAPE 1 — Créer un compte GitHub gratuit
1. Allez sur **https://github.com**
2. Cliquez **"Sign up"**
3. Entrez email + mot de passe + nom d'utilisateur
4. Vérifiez votre email

---

### ÉTAPE 2 — Créer un nouveau dépôt
1. Une fois connecté, cliquez le **"+"** en haut à droite
2. Choisissez **"New repository"**
3. Nom du dépôt : `jirama-tokens`
4. Cochez **"Public"**
5. Cliquez **"Create repository"**

---

### ÉTAPE 3 — Uploader les fichiers du projet
1. Sur la page de votre dépôt vide, cliquez **"uploading an existing file"**
2. Extrayez le fichier `jirama_flutter_app.zip` sur votre appareil
3. Glissez-déposez **TOUS** les fichiers extraits (ou cliquez "choose your files")
4. En bas, cliquez **"Commit changes"**

> ⚠️ Respectez la structure des dossiers :
> ```
> .github/workflows/build.yml
> lib/main.dart
> lib/models.dart
> lib/sms_service.dart
> lib/storage_service.dart
> android/...
> pubspec.yaml
> ```

---

### ÉTAPE 4 — Lancer la compilation
La compilation démarre **automatiquement** dès l'upload !

Sinon, lancez-la manuellement :
1. Cliquez l'onglet **"Actions"** dans votre dépôt
2. Cliquez **"Build JIRAMA APK"** à gauche
3. Cliquez **"Run workflow"** → **"Run workflow"** (bouton vert)

---

### ÉTAPE 5 — Télécharger l'APK
1. Attendez ~10 minutes que la compilation finisse (cercle vert ✅)
2. Cliquez sur le job terminé
3. En bas de page, sous **"Artifacts"**
4. Cliquez **"JIRAMA-Tokens-APK"** → téléchargement du `.apk`

---

### ÉTAPE 6 — Installer l'APK sur Android
1. Transférez le `.apk` sur votre téléphone Android
2. Ouvrez-le depuis le gestionnaire de fichiers
3. Si Android bloque : **Paramètres → Sécurité → Sources inconnues → Autoriser**
4. Installez et profitez ! 🎉

---

## ❓ Problèmes fréquents

| Problème | Solution |
|---|---|
| La compilation échoue (rouge ❌) | Cliquez sur le job pour voir l'erreur, partagez-la |
| "Sources inconnues" bloqué | Paramètres → Applications → Autoriser depuis cette source |
| L'APK ne s'installe pas | Vérifiez que votre Android est version 5.0+ |

---

**Bargass APK · JIRAMA Tokens v1.0**
